package com.blackhole.downloader

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 16)
    private val panel = Color.rgb(20, 24, 34)
    private val red = Color.rgb(235, 25, 48)
    private val purple = Color.rgb(137, 77, 255)
    private val white = Color.rgb(248, 248, 252)
    private val muted = Color.rgb(175, 183, 198)
    private lateinit var addressInput: EditText
    private lateinit var status: TextView
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            setBackgroundColor(bg)
        }
        val heading = TextView(this).apply {
            text = "♞  Abo Zahra"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(heading, lp(-1, dp(48)))
        val subtitle = TextView(this).apply {
            text = "متصفح ومحمّل • ZAMALEK"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(red)
        }
        root.addView(subtitle, lp(-1, dp(28)))

        val addressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        addressInput = EditText(this).apply {
            hint = "ابحث أو اكتب رابط الموقع"
            textSize = 14f
            setTextColor(white)
            setHintTextColor(muted)
            singleLine = true
            setPadding(dp(12), 0, dp(12), 0)
            background = rounded(panel, dp(12))
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        addressRow.addView(addressInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        val go = button("اذهب", red) { openAddress() }
        val goParams = lp(dp(70), dp(48)).apply { leftMargin = dp(6) }
        addressRow.addView(go, goParams)
        root.addView(addressRow)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("الرئيسية", purple) { webView.loadUrl("https://www.google.com") }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(4); topMargin = dp(8) })
        actions.addView(button("التنزيلات", red) { showDownloadsInfo() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(4); topMargin = dp(8) })
        root.addView(actions)

        status = TextView(this).apply {
            text = "افتح موقعًا، وعند الضغط على رابط ملف مباشر سيظهر خيار تنزيله إلى Download/Abo Zahra."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        root.addView(status, lp(-1, -2))

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (!url.isNullOrBlank()) addressInput.setText(url)
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        })
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        setContentView(root)
        webView.loadUrl("https://www.google.com")
        askPermissions()
    }

    private fun askPermissions() {
        val needed = mutableListOf<String>()
        if (android.os.Build.VERSION.SDK_INT <= 28) needed.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (android.os.Build.VERSION.SDK_INT >= 33) needed.add(android.Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }

    private val fileExtensions = setOf("pdf", "mp4", "mkv", "webm", "mp3", "m4a", "jpg", "jpeg", "png", "gif", "webp", "zip", "apk", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt")

    private fun isDirectFile(uri: Uri): Boolean {
        val ext = (uri.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        return ext in fileExtensions
    }

    private fun openAddress() {
        var raw = addressInput.text.toString().trim()
        if (raw.isEmpty()) return
        if (!raw.contains("://")) {
            raw = if (raw.contains(" ")) "https://www.google.com/search?q=" + Uri.encode(raw) else "https://$raw"
        }
        val uri = Uri.parse(raw)
        if (uri.scheme != "https" && uri.scheme != "http") {
            Toast.makeText(this, "استخدم رابطًا يبدأ بـ http أو https", Toast.LENGTH_SHORT).show()
            return
        }
        if (isDirectFile(uri)) {
            startDownload(raw, null, null, android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension((uri.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()))
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(addressInput.windowToken, 0)
            return
        }
        webView.loadUrl(raw)
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(addressInput.windowToken, 0)
    }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http")) {
            Toast.makeText(this, "الرابط غير صالح للتنزيل", Toast.LENGTH_SHORT).show(); return
        }
        try {
            val filename = URLUtil.guessFileName(url, contentDisposition, mimeType).ifBlank { "abo_zahra_file" }
            val request = DownloadManager.Request(uri)
                .setTitle(filename)
                .setDescription("Abo Zahra • Download")
                .setMimeType(mimeType)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Abo Zahra/$filename")
            if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "بدأ تنزيل $filename\nمكان الحفظ: Download/Abo Zahra"
            Toast.makeText(this, "بدأ التنزيل إلى Download/Abo Zahra", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            status.text = "لم يبدأ التنزيل. قد يكون الموقع يمنع التنزيل المباشر أو يحتاج تسجيل دخول."
            Toast.makeText(this, "تعذر تنزيل هذا الرابط", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDownloadsInfo() {
        status.text = "ملفاتك تُحفظ في: مدير الملفات > Download > Abo Zahra. ويمكنك متابعة التنزيل من إشعار أندرويد."
        Toast.makeText(this, "افتح مدير الملفات ثم Download ثم Abo Zahra", Toast.LENGTH_LONG).show()
    }

    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(color, dp(12)); setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
